paintings = [[1,"Unknown", 150, 1,2],[2,"Anxiety",189,1.5,3],[3,"Lust",89, 0.5,1],[4,"Confusion",250, 2,4],[5,"Farwell",280,1.5,3],[6,"Lost",110, 1,2],[7,"One Afternoon",350,2,4],[8,"Drip",50,1,2],[9,"Gust",210,2,4],[10, "Apologetic",510,2,4]]

